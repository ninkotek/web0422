import Card from "./Card.jsx";

function App() {
  return (
    <>
      <Card />
    </>
  );
}

export default App;
